Here are the files that contains the SQL scripts to go from a version to another.

The name of this files will be v2.sql, v3.sql... and so on, where the number represent the target version. _DO NOT_ modify the `dbVersion` param of the `appData` table, this param is autoupdated when a migration occurs.
