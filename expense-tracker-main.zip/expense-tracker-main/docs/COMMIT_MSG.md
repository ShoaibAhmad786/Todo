# Commit message convention for Monekin

To ensure a correct reading of commits and to facilitate their subsequent search or enable automation processes for the app, we use well-defined criteria when formulating commit messages. This criterion is based on the [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/), and is explained below:

In general, the same pattern is followed as explained in the documentation of this convention, which is:

```
<type>[optional scope]: <description>

[optional body]

[optional footer(s)]
```

The only condition we add here is that the description (also called subject) must start with an **uppercase** letter.

In addition, in order to simplify the process we have reduced the number of possible types, which are the same as Angular follows in its [convention](https://github.com/angular/angular/blob/main/CONTRIBUTING.md#type):

- **build**: Changes that affect the build system or external dependencies. Upgrade and remove dependencies, packages...
- **ci**: Changes to our CI configuration files and scripts
- **docs**: Documentation only changes
- **feat**: A new feature
- **fix**: A bug fix
- **perf**: A code change that improves performance
- **refactor**: A code change that neither fixes a bug nor adds a feature, move or rename files/resources...
- **test**: Adding missing tests or correcting existing tests

Usually you are going to use only the `fix` and the `feat` type.

For our project, the valid scopes are defined [here](https://github.com/enrique-lozano/Monekin/blob/main/docs/VALID_COMMIT_SCOPES.ts) along with a brief description of when to use them.

So, the final commit header (the first line of the commit, before the body and the footers) should look something like this:

```
<type>(<scope>): <short summary>
  │       │             │
  │       │             └─⫸ Summary in present tense. First letter capitalized. No period at the end.
  │       │
  │       └─⫸ Commit Scope: One of the defined in the VALID_COMMIT_SCOPES.ts
  │
  └─⫸ Commit Type: build|ci|docs|feat|fix|perf|refactor|test
```

If you have doubts you can check our [last commits](https://github.com/enrique-lozano/Monekin/commits/main) and see how they meet all of this conditions.

## Too much, right? 🤯

We know that following all this convention can be somewhat difficult, therefore, we provide you with tools so that you can carry it out:

### VSCode Extensions

- **Conventional Commits [[link](https://marketplace.visualstudio.com/items?itemName=vivaxy.vscode-conventional-commits)]**: With this great extension you can write your commit messages in the required format for this project easier. When you clone this repo, we provide the configuration for this extension that match with our requirements, so you don't have to do anything. You will see that our scopes appear automatically in the form when you run this extension. Check the link for more info on how to use it.

## A final note 📝

Despite the fact that this convention is mandatory for this project and that it is very easy to carry out thanks to the aforementioned tools, we are not going to kill anyone who does not follow it to the letter.

What we want is that you feel comfortable collaborating, that you try, that you mess around and yes, also that you make mistakes. In the event that this convention is not followed in some of your pull requests, the worst thing that can happen to you is that we make a `squash commit`, that is, that we unify all your commits into one with a different message.
