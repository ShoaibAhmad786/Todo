export 'native.dart' if (dart.library.js) 'web.dart';
