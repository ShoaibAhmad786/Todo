int get currentYear => DateTime.now().year;
int get currentMonth => DateTime.now().month;
int get currentDayOfMonth => DateTime.now().day;

/// Max label lenght for the categories and transactions titles
const int maxLabelLenghtForDisplayNames = 25;
