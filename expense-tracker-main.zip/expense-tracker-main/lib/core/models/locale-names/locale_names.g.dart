// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'locale_names.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LocaleNames _$LocaleNamesFromJson(Map<String, dynamic> json) => LocaleNames(
      en: json['en'] as String,
      es: json['es'] as String?,
    );

Map<String, dynamic> _$LocaleNamesToJson(LocaleNames instance) =>
    <String, dynamic>{
      'en': instance.en,
      'es': instance.es,
    };
