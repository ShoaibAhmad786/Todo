// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supported_icon.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SupportedIcon _$SupportedIconFromJson(Map<String, dynamic> json) =>
    SupportedIcon(
      id: json['id'] as String,
      scope: json['scope'] as String,
    );

Map<String, dynamic> _$SupportedIconToJson(SupportedIcon instance) =>
    <String, dynamic>{
      'id': instance.id,
      'scope': instance.scope,
    };
